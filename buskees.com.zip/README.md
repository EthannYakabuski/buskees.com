This was created using the Amazon Web Services tutorial code as a base and then modified from there
